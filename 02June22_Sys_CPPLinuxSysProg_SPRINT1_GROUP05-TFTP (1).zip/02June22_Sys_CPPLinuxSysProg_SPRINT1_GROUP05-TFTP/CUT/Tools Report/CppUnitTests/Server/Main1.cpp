#include "server.h"

int main()
{       
        
   
        int server_port;
	Server s;
	char* ip_addr1 = "127.0.0.1";
	s.setIp_addr((char*)"127.0.0.1");
	s.setServer_port(server_port);
	s.display();
	return 0;	
}