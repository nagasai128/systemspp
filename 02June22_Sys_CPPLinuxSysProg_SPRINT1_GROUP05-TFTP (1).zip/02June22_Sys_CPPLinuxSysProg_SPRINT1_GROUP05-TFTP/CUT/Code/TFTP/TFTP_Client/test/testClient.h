#ifndef __TESTCLIENT_H__
#define __TESTCLIENT_H__

/*************************************************************************************
 *                               FUNCTION DEFINITIONS
 ************************************************************************************/

void testMakeRRQ(void);
void testMakeWRQ(void);
void testMakeACK(void);
void testMakeData(void);
void testMakeERR(void);
 

#endif
