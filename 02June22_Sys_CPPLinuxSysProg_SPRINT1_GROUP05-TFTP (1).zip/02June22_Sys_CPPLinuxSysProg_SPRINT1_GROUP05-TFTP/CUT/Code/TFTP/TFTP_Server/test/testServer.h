#ifndef __TESTSERVER_H__
#define __TESTSERVER_H__

/*************************************************************************************
 *                               FUNCTION DEFINITIONS
 ************************************************************************************/


void testMakeACK(void);
void testMakeData(void);
void testMakeERR(void);
 

#endif
