#include<iostream>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>

using namespace std;
int main()
{
        int i,j,pid,status, exitstrat;

        pid = fork();

        if (pid ==0)
        {
                cout<<"child strats"<<endl;
                for(i=1;i<=200;i++)
                {
                        if(i%2 != 0)
                        {
                                cout<<"i="<<i<<endl;
                        }
                cout<<"the child ends"<<endl;
                }
        }
        else
        {
                cout<<"parents strats"<<endl;
                for(j=0;j<=200;j++)
                {
                        if(j%2 == 0)
                        {
                                cout<<"j="<<j<<endl;
                        }
                }
        }
        wait(0);
        cout<<"the parent ends"<<endl;
        return 0;
}
